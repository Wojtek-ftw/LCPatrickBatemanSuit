## v2.1.0
- Fixed directory structure to automatically insert skin into game. Really trust me :)

## v2.0.0
- Fixed directory structure to automatically insert skin into game.